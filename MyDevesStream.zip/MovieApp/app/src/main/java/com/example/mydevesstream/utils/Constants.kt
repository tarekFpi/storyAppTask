package com.example.mydevesstream.utils

class Constants {

    companion object BaseURL{
        const val BASE_URL = "https://www.omdbapi.com"
    }
}