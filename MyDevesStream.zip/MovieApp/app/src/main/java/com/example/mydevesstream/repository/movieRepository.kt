package com.example.mydevesstream.repository
import com.example.mydevesstream.model.movieList.movieResponseModel
import com.example.mydevesstream.retrofit.ApiService
import javax.inject.Inject

class MovieRepository @Inject constructor(val apiService: ApiService){


            suspend fun fetchMovies(page: Int): movieResponseModel {

                return apiService.getItems(page)
        }


}